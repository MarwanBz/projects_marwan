<template>
<p>

    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus sed dolor lectus. Proin blandit, nulla at sodales rhoncus, mauris lectus interdum nulla, sed dictum velit nisl ut tortor. In vel convallis urna. Aenean sollicitudin ultricies ipsum non volutpat. Nam sed dictum tellus, nec tempor tortor. Interdum et malesuada fames ac ante ipsum primis in faucibus. Mauris eleifend ullamcorper ultricies. Suspendisse mauris tortor, vehicula sed gravida non, commodo eget neque. Vestibulum turpis purus, feugiat consequat gravida in, congue vitae sem. Morbi ultricies pretium tincidunt. Vestibulum egestas quam sit amet augue accumsan cursus. Donec sed placerat mi. Nam consectetur suscipit lectus id maximus. Mauris mi enim, fringilla a nulla ut, volutpat pellentesque nibh.

    Pellentesque libero arcu, cursus vel tristique vel, finibus ac est. Donec nibh sem, pulvinar blandit leo a, lobortis vestibulum tellus. Cras blandit nulla urna, a condimentum neque viverra vel. Morbi nec metus nec metus consectetur porttitor. Fusce facilisis est non urna elementum, id vestibulum velit vehicula. Praesent in metus cursus, malesuada ipsum nec, tincidunt tortor. Quisque gravida a odio eget suscipit.

    Morbi vel tristique felis, nec tempor lectus. Nullam risus mi, ultrices nec enim eu, efficitur condimentum turpis. In ac velit eget leo scelerisque scelerisque sed eu quam. Cras dignissim faucibus eros sed pretium. Ut imperdiet leo nec semper ullamcorper. Aenean at lectus vel nisl aliquam vulputate eget sed ante. Nullam ac enim eget diam ullamcorper sagittis. Suspendisse faucibus consectetur egestas. Fusce ut sem in lorem pulvinar luctus sit amet et libero. Vestibulum vulputate elit nunc, et scelerisque turpis placerat quis.

    Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque pulvinar, mauris ac rhoncus ultrices, felis est bibendum turpis, volutpat mollis nisl felis in elit. Nam et sem in nisi blandit egestas. Nam ut risus mauris. Donec molestie odio eu urna pharetra varius. In nunc ipsum, tempus ut enim ut, feugiat facilisis magna. Nullam tincidunt ac est eget viverra. Cras vitae euismod nisl, sit amet pellentesque nunc. Fusce sit amet orci arcu. Praesent bibendum lacus nec lectus ullamcorper ullamcorper. Nullam blandit orci suscipit suscipit ullamcorper.

    Nullam a lectus placerat, suscipit nibh at, fermentum sem. Maecenas volutpat augue id faucibus vulputate. Fusce urna quam, faucibus a maximus vitae, viverra ac ligula. Maecenas quis eleifend justo, sit amet sagittis ante. Mauris faucibus semper felis et posuere. Vivamus felis urna, maximus eget efficitur id, interdum sed diam. Phasellus commodo ac quam eu rhoncus. Curabitur nisl tellus, tempus quis magna bibendum, sollicitudin aliquet est.
</p>
</template>

<style scoped>
/*-------------------------------------------*\
    CSS Normalisation 
\*-------------------------------------------*/

p {
    margin: 0;
    padding: 0;
}
</style>
